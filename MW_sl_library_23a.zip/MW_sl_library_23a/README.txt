Arduino Libraries required for Simulink Arduino Support package

* Adafruit_BusIO - 1.4.1
* Adafruit_GFX_Library - 1.10.0
* Adafruit_ILI9341 - 1.5.6
* Adafruit_LiquidCrystal - 1.1.0
* ArduinoJson - 6.13.0
* ArduinoModbus - 1.0.2
* ArduinoRS485 - 1.0.0
* SdFat - 2.0.5
* Websocket
* Adafruit TouchScreen - 1.1.1

New in 22b
* PubSubClient - 2.8